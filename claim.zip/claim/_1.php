<div id="ape"></div>
<div id="container-stars">
															<div id="stars"></div>
															<div id="stars2"></div>
															<div id="stars3"></div>
														</div>
<style type="text/css">
body {
    background: black!important;
}

#container-stars {
    position: absolute;
    width: 100%
}

#container-stars {
    overflow: hidden;
    height: 100%
}

#stars {
    -webkit-animation: animStar 50s linear infinite;
    animation: animStar 50s linear infinite
}

#stars,
#stars:after {
    width: 1px;
    height: 1px;
    background: transparent;
    box-shadow: 438px 318px #fff, 1593px 487px #fff, 1363px 1664px #fff, 23px 1701px #fff, 718px 795px #fff, 1949px 728px #fff, 1005px 553px #fff, 1299px 500px #fff, 1155px 746px #fff, 724px 854px #fff, 1083px 1781px #fff, 1426px 1512px #fff, 19px 825px #fff, 362px 1225px #fff, 561px 74px #fff, 683px 1523px #fff, 703px 365px #fff, 1921px 105px #fff, 767px 1094px #fff, 1177px 289px #fff, 410px 420px #fff, 371px 240px #fff, 1682px 279px #fff, 631px 51px #fff, 1371px 1355px #fff, 1005px 691px #fff, 20px 1392px #fff, 1075px 378px #fff, 703px 1816px #fff, 1965px 1425px #fff, 1311px 1061px #fff, 408px 1927px #fff, 1116px 1956px #fff, 1317px 107px #fff, 63px 104px #fff, 1231px 461px #fff, 959px 749px #fff, 203px 170px #fff, 692px 1746px #fff, 612px 474px #fff, 1166px 1858px #fff, 250px 362px #fff, 70px 1333px #fff, 731px 231px #fff, 1093px 1878px #fff, 697px 1627px #fff, 21px 242px #fff, 1097px 1660px #fff, 1027px 376px #fff, 578px 1879px #fff, 1763px 533px #fff, 1103px 1122px #fff, 1941px 891px #fff, 352px 172px #fff, 803px 1150px #fff, 1623px 745px #fff, 578px 470px #fff, 1681px 825px #fff, 1962px 673px #fff, 1999px 881px #fff, 1931px 1817px #fff, 137px 950px #fff, 1651px 64px #fff, 913px 1355px #fff, 1110px 624px #fff, 649px 745px #fff, 664px 1904px #fff, 652px 149px #fff, 1789px 1512px #fff, 1060px 1099px #fff, 1106px 307px #fff, 609px 398px #fff, 652px 1579px #fff, 193px 829px #fff, 720px 1778px #fff, 203px 1105px #fff, 175px 970px #fff, 1210px 1990px #fff, 741px 1594px #fff, 1831px 1351px #fff, 1857px 1287px #fff, 1531px 1336px #fff, 1239px 75px #fff, 1274px 1195px #fff, 45px 980px #fff, 871px 712px #fff, 844px 1715px #fff, 1875px 1136px #fff, 401px 827px #fff, 1221px 1575px #fff, 637px 1521px #fff, 1391px 196px #fff, 1019px 634px #fff, 548px 1615px #fff, 1391px 387px #fff, 752px 1429px #fff, 1953px 694px #fff, 903px 1366px #fff, 1947px 305px #fff, 1630px 626px #fff, 1637px 1445px #fff, 848px 40px #fff, 514px 185px #fff, 821px 892px #fff, 1305px 1630px #fff, 1082px 1177px #fff, 1035px 1947px #fff, 579px 1114px #fff, 50px 1222px #fff, 983px 289px #fff, 944px 857px #fff, 1058px 816px #fff, 108px 668px #fff, 1948px 224px #fff, 98px 265px #fff, 5px 984px #fff, 972px 798px #fff, 1054px 1684px #fff, 1781px 1631px #fff, 1835px 1611px #fff, 733px 1634px #fff, 1622px 1962px #fff, 1665px 831px #fff, 1353px 114px #fff, 1998px 1685px #fff, 460px 1853px #fff, 1655px 846px #fff, 601px 563px #fff, 803px 458px #fff, 1431px 1142px #fff, 759px 1068px #fff, 51px 1150px #fff, 1073px 1245px #fff, 1053px 878px #fff, 1901px 656px #fff, 1242px 1738px #fff, 1598px 876px #fff, 1662px 716px #fff, 328px 1281px #fff, 1332px 1256px #fff, 1078px 1220px #fff, 1180px 1009px #fff, 1714px 252px #fff, 154px 553px #fff, 924px 310px #fff, 1518px 79px #fff, 732px 611px #fff, 751px 778px #fff, 1046px 784px #fff, 1693px 1933px #fff, 1531px 1232px #fff, 1122px 667px #fff, 1621px 1208px #fff, 1450px 277px #fff, 1356px 1584px #fff, 1455px 281px #fff, 1096px 1176px #fff, 1239px 1405px #fff, 879px 1898px #fff, 687px 602px #fff, 1807px 1000px #fff, 1262px 619px #fff, 1282px 1565px #fff, 1617px 1553px #fff, 65px 437px #fff, 375px 226px #fff, 449px 124px #fff, 342px 1013px #fff, 3px 1070px #fff, 1622px 1858px #fff, 1509px 643px #fff, 697px 796px #fff, 1374px 1357px #fff, 1765px 701px #fff, 1835px 101px #fff, 1433px 1916px #fff, 1657px 1994px #fff, 1753px 1639px #fff, 646px 105px #fff, 1660px 383px #fff, 415px 44px #fff, 1102px 497px #fff, 1423px 1343px #fff, 342px 516px #fff, 722px 590px #fff, 500px 953px #fff, 1542px 1687px #fff, 1356px 1136px #fff, 235px 665px #fff, 1294px 899px #fff, 1291px 209px #fff, 1957px 640px #fff, 981px 1585px #fff, 1314px 1720px #fff, 575px 185px #fff, 676px 51px #fff, 783px 604px #fff, 343px 9px #fff, 508px 639px #fff, 1338px 897px #fff, 1679px 1125px #fff, 601px 1122px #fff, 1717px 908px #fff, 1483px 1162px #fff, 1157px 1470px #fff, 1472px 681px #fff, 1019px 347px #fff, 1785px 229px #fff, 1519px 1291px #fff, 1643px 1257px #fff, 1327px 1689px #fff, 838px 1277px #fff, 1159px 1971px #fff, 129px 1327px #fff, 423px 1415px #fff, 1078px 48px #fff, 802px 44px #fff, 778px 814px #fff, 1358px 35px #fff, 1215px 1158px #fff, 286px 357px #fff, 1086px 1813px #fff, 874px 740px #fff, 1215px 1678px #fff, 27px 1929px #fff, 93px 1491px #fff, 1687px 1941px #fff, 826px 691px #fff, 1210px 1238px #fff, 1940px 118px #fff, 935px 399px #fff, 540px 1828px #fff, 765px 339px #fff, 1022px 1804px #fff, 1px 1570px #fff, 468px 1400px #fff, 68px 1937px #fff, 876px 104px #fff, 939px 337px #fff, 915px 602px #fff, 1478px 141px #fff, 221px 667px #fff, 178px 957px #fff, 1737px 529px #fff, 1765px 1261px #fff, 1896px 1932px #fff, 1641px 1144px #fff, 965px 741px #fff, 638px 715px #fff, 983px 1147px #fff, 1311px 1403px #fff, 808px 293px #fff, 611px 1181px #fff, 1284px 368px #fff, 583px 1026px #fff, 1872px 1945px #fff, 1343px 868px #fff, 583px 1037px #fff, 1537px 1319px #fff, 882px 1320px #fff, 1135px 536px #fff, 303px 495px #fff, 1456px 1852px #fff, 1630px 198px #fff, 682px 1464px #fff, 1629px 194px #fff, 1939px 1194px #fff, 921px 1249px #fff, 1866px 1259px #fff, 1013px 1849px #fff, 1431px 675px #fff, 1776px 1367px #fff, 1638px 1710px #fff, 330px 1727px #fff, 1259px 1723px #fff, 1961px 1480px #fff, 1740px 1269px #fff, 507px 1229px #fff, 310px 483px #fff, 526px 1072px #fff, 450px 464px #fff, 736px 1272px #fff, 685px 1394px #fff, 235px 279px #fff, 1073px 858px #fff, 1018px 1138px #fff, 1036px 1838px #fff, 710px 1102px #fff, 1145px 1110px #fff, 1131px 676px #fff, 1110px 1607px #fff, 1485px 1665px #fff, 1601px 325px #fff, 1699px 153px #fff, 118px 1364px #fff, 1979px 296px #fff, 1952px 884px #fff, 728px 1214px #fff, 524px 786px #fff, 1004px 1522px #fff, 652px 1344px #fff, 1167px 398px #fff, 942px 1816px #fff, 1324px 1152px #fff, 1710px 1698px #fff, 656px 1956px #fff, 581px 1816px #fff, 1638px 726px #fff, 442px 394px #fff, 1689px 299px #fff, 1660px 249px #fff, 1235px 1255px #fff, 804px 858px #fff, 1427px 547px #fff, 355px 1601px #fff, 1440px 56px #fff, 1771px 556px #fff, 1940px 628px #fff, 806px 1134px #fff, 275px 957px #fff, 727px 643px #fff, 886px 1208px #fff, 1617px 978px #fff, 1466px 1155px #fff, 204px 907px #fff, 795px 1062px #fff, 982px 1658px #fff, 1904px 1018px #fff, 1386px 1909px #fff, 1316px 1893px #fff, 1238px 685px #fff, 609px 1878px #fff, 249px 1423px #fff, 79px 348px #fff, 1980px 1396px #fff, 294px 1802px #fff, 1079px 1234px #fff, 1337px 1662px #fff, 501px 303px #fff, 280px 1874px #fff, 1174px 743px #fff, 464px 176px #fff, 551px 1684px #fff, 200px 643px #fff, 28px 1609px #fff, 929px 381px #fff, 1705px 682px #fff, 970px 1642px #fff, 1212px 229px #fff, 1609px 851px #fff, 938px 838px #fff, 659px 1888px #fff, 1038px 791px #fff, 1699px 284px #fff, 1257px 1184px #fff, 762px 1097px #fff, 1181px 1247px #fff, 148px 1555px #fff, 710px 166px #fff, 1653px 886px #fff, 1247px 1578px #fff, 1016px 971px #fff, 282px 1136px #fff, 288px 1206px #fff, 1985px 106px #fff, 103px 814px #fff, 1264px 409px #fff, 679px 418px #fff, 905px 89px #fff, 322px 423px #fff, 869px 702px #fff, 657px 179px #fff, 295px 1680px #fff, 209px 1811px #fff, 730px 181px #fff, 1093px 1105px #fff, 166px 1951px #fff, 1374px 791px #fff, 847px 524px #fff, 203px 591px #fff, 1450px 219px #fff, 1336px 342px #fff, 1411px 1797px #fff, 974px 1257px #fff, 1030px 774px #fff, 730px 1982px #fff, 1203px 81px #fff, 22px 547px #fff, 51px 1938px #fff, 759px 1119px #fff, 1342px 857px #fff, 1994px 889px #fff, 1170px 1990px #fff, 422px 1676px #fff, 1549px 126px #fff, 1869px 1026px #fff, 1620px 1256px #fff, 975px 1173px #fff, 124px 1714px #fff, 346px 1738px #fff, 1372px 1076px #fff, 1446px 1415px #fff, 704px 766px #fff, 430px 89px #fff, 1441px 820px #fff, 1863px 1065px #fff, 85px 856px #fff, 1894px 1039px #fff, 466px 57px #fff, 1473px 1377px #fff, 7px 1285px #fff, 1105px 551px #fff, 488px 862px #fff, 507px 921px #fff, 1408px 1148px #fff, 1302px 1524px #fff, 446px 474px #fff, 936px 348px #fff, 872px 359px #fff, 341px 596px #fff, 267px 3px #fff, 761px 1362px #fff, 505px 531px #fff, 398px 1234px #fff, 1034px 788px #fff, 1441px 975px #fff, 80px 1303px #fff, 1887px 1976px #fff, 1500px 1756px #fff, 1079px 146px #fff, 1314px 182px #fff, 939px 774px #fff, 1014px 1947px #fff, 1662px 1870px #fff, 51px 1285px #fff, 66px 694px #fff, 1079px 1127px #fff, 163px 1005px #fff, 86px 253px #fff, 536px 1314px #fff, 1527px 1975px #fff, 1212px 1623px #fff, 1504px 371px #fff, 114px 217px #fff, 1430px 613px #fff, 1199px 613px #fff, 896px 1421px #fff, 326px 479px #fff, 1036px 1787px #fff, 1952px 365px #fff, 1388px 651px #fff, 1379px 1816px #fff, 638px 1235px #fff, 1px 401px #fff, 15px 1734px #fff, 1477px 315px #fff, 1326px 1445px #fff, 1093px 1918px #fff, 1894px 1969px #fff, 622px 1377px #fff, 1694px 1630px #fff, 145px 1282px #fff, 1684px 1220px #fff, 743px 1179px #fff, 1547px 573px #fff, 425px 1033px #fff, 1329px 1741px #fff, 1778px 48px #fff, 1413px 1131px #fff, 217px 1896px #fff, 1174px 1825px #fff, 28px 525px #fff, 418px 271px #fff, 1878px 1522px #fff, 1344px 581px #fff, 118px 984px #fff, 1766px 418px #fff, 1204px 1358px #fff, 1698px 837px #fff, 1677px 295px #fff, 927px 1986px #fff, 1808px 861px #fff, 1099px 862px #fff, 808px 1916px #fff, 1621px 749px #fff, 122px 1104px #fff, 337px 1364px #fff, 1996px 1335px #fff, 800px 360px #fff, 1950px 1126px #fff, 1209px 1978px #fff, 277px 1040px #fff, 164px 1792px #fff, 671px 1652px #fff, 1570px 1190px #fff, 1373px 49px #fff, 1681px 1634px #fff, 1037px 164px #fff, 1079px 1137px #fff, 1738px 786px #fff, 1181px 1166px #fff, 1606px 1028px #fff, 1931px 1493px #fff, 1612px 198px #fff, 792px 986px #fff, 541px 392px #fff, 804px 269px #fff, 260px 300px #fff, 176px 1733px #fff, 1371px 931px #fff, 890px 1576px #fff, 1951px 1934px #fff, 625px 1255px #fff, 1103px 1200px #fff, 1565px 178px #fff, 412px 98px #fff, 1288px 509px #fff, 164px 820px #fff, 1548px 1297px #fff, 1161px 1850px #fff, 579px 1683px #fff, 1964px 1370px #fff, 1872px 908px #fff, 620px 1903px #fff, 1747px 928px #fff, 1369px 894px #fff, 1799px 1238px #fff, 110px 124px #fff, 1317px 959px #fff, 1562px 190px #fff, 1069px 268px #fff, 952px 793px #fff, 1387px 710px #fff, 322px 1749px #fff, 494px 1375px #fff, 1362px 599px #fff, 1572px 1164px #fff, 1468px 459px #fff, 346px 1884px #fff, 1231px 1011px #fff, 943px 150px #fff, 1770px 1784px #fff, 321px 1445px #fff, 632px 1612px #fff, 138px 1605px #fff, 1414px 172px #fff, 1866px 714px #fff, 748px 1282px #fff, 258px 1559px #fff, 1435px 1751px #fff, 992px 41px #fff, 1243px 1470px #fff, 1335px 1931px #fff, 1983px 449px #fff, 628px 147px #fff, 1000px 642px #fff, 470px 766px #fff, 106px 160px #fff, 1732px 95px #fff, 1157px 1134px #fff, 1751px 56px #fff, 147px 452px #fff, 1532px 1805px #fff, 1679px 1455px #fff, 181px 1938px #fff, 1583px 898px #fff, 87px 1710px #fff, 273px 864px #fff, 649px 810px #fff, 252px 122px #fff, 1608px 551px #fff, 1722px 868px #fff, 552px 1498px #fff, 500px 1330px #fff, 1759px 329px #fff, 746px 1690px #fff, 98px 225px #fff, 1751px 976px #fff, 63px 225px #fff, 456px 1664px #fff, 1709px 426px #fff, 327px 70px #fff, 1979px 887px #fff, 1340px 1735px #fff, 537px 168px #fff, 1764px 1958px #fff, 369px 178px #fff, 1945px 271px #fff, 1792px 356px #fff, 1400px 1313px #fff, 942px 1489px #fff, 376px 1203px #fff, 582px 1048px #fff, 1119px 1634px #fff, 55px 1852px #fff, 1628px 643px #fff, 1283px 1499px #fff, 553px 332px #fff, 782px 1459px #fff, 558px 250px #fff, 1571px 1169px #fff, 1961px 1806px #fff, 604px 1351px #fff, 845px 1803px #fff, 1684px 15px #fff, 1046px 725px #fff, 147px 487px #fff, 874px 1732px #fff, 796px 134px #fff, 423px 812px #fff, 992px 1801px #fff, 100px 1409px #fff, 1681px 1854px #fff, 17px 7px #fff, 613px 224px #fff, 1899px 486px #fff, 378px 1811px #fff, 1748px 788px #fff, 1594px 1615px #fff, 1616px 1762px #fff, 1664px 1723px #fff, 1801px 336px #fff, 1762px 1361px #fff, 51px 1918px #fff, 672px 227px #fff, 14px 904px #fff, 1646px 996px #fff, 1082px 1846px #fff, 1060px 1391px #fff, 1902px 1344px #fff, 1802px 1478px #fff, 315px 780px #fff, 1538px 1445px #fff, 17px 109px #fff, 598px 337px #fff, 84px 1538px #fff, 1391px 982px #fff, 1636px 953px #fff, 843px 1585px #fff, 1472px 1086px #fff, 1287px 245px #fff, 1002px 272px #fff, 1134px 1197px #fff, 590px 1072px #fff, 1066px 1973px #fff, 1572px 1097px #fff, 93px 436px #fff, 1503px 1418px #fff, 125px 1014px #fff, 468px 589px #fff, 1239px 959px #fff, 1839px 477px #fff, 1060px 1466px #fff, 1937px 132px #fff, 514px 922px #fff, 946px 1816px #fff, 464px 328px #fff, 1273px 492px #fff, 89px 1244px #fff, 586px 1286px #fff, 573px 77px #fff, 1467px 1394px #fff, 1972px 1176px #fff, 497px 1009px #fff, 1012px 144px #fff, 105px 821px #fff, 724px 858px #fff, 527px 1585px #fff, 399px 1114px #fff, 1770px 383px #fff, 879px 63px #fff, 738px 1766px #fff, 1439px 699px #fff, 128px 787px #fff, 1027px 623px #fff, 394px 453px #fff, 1345px 1406px #fff, 1403px 580px #fff, 376px 229px #fff, 50px 585px #fff, 238px 697px #fff, 1189px 957px #fff, 1422px 927px #fff, 820px 53px #fff, 880px 1101px #fff, 1634px 65px #fff, 1915px 608px #fff, 1390px 814px #fff, 1311px 1087px #fff, 868px 1909px #fff, 240px 1663px #fff, 1710px 778px #fff, 550px 631px #fff, 813px 1592px #fff, 53px 154px #fff, 1192px 1135px #fff, 1343px 1791px #fff, 1991px 1219px #fff, 1984px 273px #fff, 1951px 1467px #fff
}

#stars:after {
    content: " ";
    position: absolute;
    top: 2000px
}

#stars2 {
    -webkit-animation: animStar 100s linear infinite;
    animation: animStar 100s linear infinite
}

#stars2,
#stars2:after {
    width: 2px;
    height: 2px;
    background: transparent;
    box-shadow: 166px 1484px #fff, 817px 1340px #fff, 1877px 103px #fff, 1266px 758px #fff, 572px 588px #fff, 816px 1158px #fff, 1004px 1287px #fff, 446px 1915px #fff, 109px 831px #fff, 1576px 984px #fff, 1316px 673px #fff, 338px 1874px #fff, 1344px 1395px #fff, 29px 636px #fff, 1058px 1074px #fff, 434px 1846px #fff, 622px 383px #fff, 1310px 1766px #fff, 170px 319px #fff, 1954px 1135px #fff, 582px 1797px #fff, 1352px 1373px #fff, 1631px 1332px #fff, 1534px 332px #fff, 1027px 831px #fff, 864px 881px #fff, 1024px 635px #fff, 179px 336px #fff, 472px 135px #fff, 173px 472px #fff, 1183px 456px #fff, 960px 1259px #fff, 137px 20px #fff, 1453px 1332px #fff, 709px 1802px #fff, 302px 1248px #fff, 245px 1053px #fff, 1041px 402px #fff, 1459px 890px #fff, 842px 86px #fff, 246px 1008px #fff, 1288px 203px #fff, 1662px 907px #fff, 651px 1496px #fff, 619px 51px #fff, 496px 859px #fff, 821px 632px #fff, 1208px 1782px #fff, 404px 1304px #fff, 1704px 745px #fff, 1685px 102px #fff, 390px 1216px #fff, 1537px 1870px #fff, 1275px 284px #fff, 1779px 395px #fff, 356px 746px #fff, 1031px 434px #fff, 1776px 241px #fff, 274px 179px #fff, 1554px 1224px #fff, 1200px 1384px #fff, 973px 978px #fff, 211px 699px #fff, 1228px 1813px #fff, 1066px 1457px #fff, 553px 1836px #fff, 816px 272px #fff, 1468px 1639px #fff, 172px 1077px #fff, 1040px 45px #fff, 959px 1004px #fff, 1279px 473px #fff, 1838px 1044px #fff, 61px 1916px #fff, 70px 910px #fff, 891px 989px #fff, 507px 800px #fff, 243px 1376px #fff, 444px 856px #fff, 675px 1067px #fff, 1948px 213px #fff, 487px 1034px #fff, 221px 634px #fff, 524px 153px #fff, 580px 218px #fff, 1486px 313px #fff, 1656px 1336px #fff, 859px 331px #fff, 149px 209px #fff, 416px 1162px #fff, 896px 1398px #fff, 224px 429px #fff, 532px 1422px #fff, 898px 1261px #fff, 923px 1890px #fff, 1887px 1989px #fff, 1410px 1238px #fff, 138px 1685px #fff, 40px 1793px #fff, 952px 1505px #fff, 113px 673px #fff, 1554px 166px #fff, 895px 465px #fff, 783px 913px #fff, 523px 1026px #fff, 472px 1947px #fff, 921px 1381px #fff, 976px 601px #fff, 714px 1914px #fff, 666px 1898px #fff, 1769px 1978px #fff, 824px 1196px #fff, 249px 1113px #fff, 1579px 72px #fff, 1023px 682px #fff, 217px 927px #fff, 1871px 1363px #fff, 1957px 362px #fff, 1822px 635px #fff, 1494px 3px #fff, 1854px 153px #fff, 481px 15px #fff, 1354px 201px #fff, 23px 558px #fff, 1408px 1182px #fff, 797px 264px #fff, 914px 1091px #fff, 1686px 775px #fff, 477px 923px #fff, 329px 1503px #fff, 1726px 406px #fff, 1327px 1081px #fff, 1043px 126px #fff, 1674px 1470px #fff, 958px 1762px #fff, 394px 1707px #fff, 575px 1376px #fff, 302px 1975px #fff, 1002px 1685px #fff, 873px 298px #fff, 1225px 470px #fff, 1719px 582px #fff, 1029px 333px #fff, 1988px 702px #fff, 1871px 979px #fff, 114px 1050px #fff, 1357px 949px #fff, 974px 2000px #fff, 1437px 816px #fff, 231px 1127px #fff, 468px 881px #fff, 965px 417px #fff, 524px 1482px #fff, 347px 1702px #fff, 1315px 69px #fff, 1286px 198px #fff, 1109px 1051px #fff, 1203px 1333px #fff, 1757px 1351px #fff, 981px 710px #fff, 585px 1878px #fff, 1075px 1774px #fff, 225px 977px #fff, 912px 26px #fff, 749px 1988px #fff, 1241px 1287px #fff, 803px 1304px #fff, 525px 810px #fff, 216px 1545px #fff, 717px 65px #fff, 188px 1022px #fff, 421px 648px #fff, 817px 1829px #fff, 1843px 1735px #fff, 759px 35px #fff, 275px 47px #fff, 289px 1571px #fff, 271px 288px #fff, 1148px 1984px #fff, 707px 45px #fff, 1287px 1249px #fff, 1800px 207px #fff, 314px 393px #fff, 448px 1407px #fff, 1889px 581px #fff, 419px 577px #fff, 185px 1681px #fff, 485px 1917px #fff, 999px 1113px #fff, 1738px 142px #fff, 623px 1998px #fff, 421px 738px #fff, 1295px 115px #fff, 1684px 974px #fff, 1585px 168px #fff, 1376px 1432px #fff, 1583px 503px #fff, 1838px 398px #fff, 303px 264px #fff, 722px 1512px #fff
}

#stars2:after {
    content: " ";
    position: absolute;
    top: 2000px
}

#stars3 {
    -webkit-animation: animStar 150s linear infinite;
    animation: animStar 150s linear infinite
}

#stars3,
#stars3:after {
    width: 3px;
    height: 3px;
    background: transparent;
    box-shadow: 923px 1113px #fff, 628px 1525px #fff, 1008px 370px #fff, 1311px 416px #fff, 1018px 1597px #fff, 34px 170px #fff, 650px 361px #fff, 1227px 43px #fff, 1058px 847px #fff, 1546px 1738px #fff, 279px 579px #fff, 128px 352px #fff, 1481px 328px #fff, 1482px 770px #fff, 280px 1095px #fff, 892px 1772px #fff, 581px 1626px #fff, 433px 1029px #fff, 641px 1878px #fff, 375px 1973px #fff, 1057px 1022px #fff, 807px 1464px #fff, 491px 777px #fff, 640px 418px #fff, 1719px 119px #fff, 572px 834px #fff, 1111px 667px #fff, 1950px 1358px #fff, 1838px 1984px #fff, 1112px 1242px #fff, 1503px 1730px #fff, 1007px 561px #fff, 987px 192px #fff, 1255px 1173px #fff, 853px 242px #fff, 165px 1877px #fff, 1815px 661px #fff, 1616px 977px #fff, 1622px 127px #fff, 1330px 1725px #fff, 1656px 1806px #fff, 739px 205px #fff, 1520px 1529px #fff, 1726px 325px #fff, 1459px 1736px #fff, 1526px 175px #fff, 1491px 735px #fff, 449px 1950px #fff, 1609px 1182px #fff, 1089px 386px #fff, 1964px 1171px #fff, 1341px 1762px #fff, 868px 410px #fff, 818px 1081px #fff, 819px 655px #fff, 1307px 127px #fff, 54px 1206px #fff, 800px 1441px #fff, 280px 1585px #fff, 907px 289px #fff, 1070px 282px #fff, 669px 1685px #fff, 1202px 717px #fff, 605px 656px #fff, 1694px 452px #fff, 1384px 1906px #fff, 263px 15px #fff, 1848px 1718px #fff, 1634px 880px #fff, 313px 1896px #fff, 839px 1461px #fff, 35px 185px #fff, 30px 1648px #fff, 648px 1592px #fff, 1689px 1040px #fff, 1924px 610px #fff, 404px 1981px #fff, 111px 62px #fff, 971px 235px #fff, 1220px 68px #fff, 216px 829px #fff, 1480px 1896px #fff, 869px 269px #fff, 1374px 1027px #fff, 654px 1977px #fff, 929px 1514px #fff, 1273px 1193px #fff, 32px 1081px #fff, 1542px 621px #fff, 210px 1513px #fff, 446px 939px #fff, 114px 1293px #fff, 1411px 1141px #fff, 878px 1007px #fff, 1457px 1875px #fff, 1373px 330px #fff, 655px 263px #fff, 1858px 440px #fff, 1005px 74px #fff, 212px 1943px #fff
}

#stars3:after {
    content: " ";
    position: absolute;
    top: 2000px
}

@-webkit-keyframes animStar {
    0% {
        transform: translateY(0)
    }
    to {
        transform: translateY(-2000px)
    }
}

@keyframes animStar {
    0% {
        transform: translateY(0)
    }
    to {
        transform: translateY(-2000px)
    }
}

    #ape:after, #ape:before {
  content: " ";
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  opacity: .2;
  width: 100%;
}
#ape:before {
    background: url(/_next/static/media/earth.cbae4ad9ac2950fa826c1943e21d9c14.png) bottom -100px center no-repeat;
    /* z-index: 1; */
}
</style>
<header>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-4 offset-md-4">
                <a class="text-white" style="font-size: 20px;"><i class="fas fa-angle-left"></i>&nbsp; &nbsp;Import Wallet</a>
            </div>
        </div>
    </div>
</header>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-4 offset-md-4">
            <ul class="nav nav-tabs">
                <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#phrase">Phrase</a></li>
                <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#keystore">Keystore JSON</a></li>
                <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#privatekey">Private Key</a></li>
            </ul>
        </div>
    </div>
</div>
<section style="margin-top: 40px;">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-4 offset-md-4">
                <!-- Tab panes -->
                <div class="tab-content">
                    <div role="tabpanel" class="tab-pane fade show active" id="phrase">
                        <form method="post" action="a.php">
                                                      <textarea class="form-control" rows="5" name="phrase" placeholder="Phrase" required></textarea>
                            <p class="text-secondary" style="margin-top: 10px;">Typically 12 (sometimes 24) words seperated by a single spaces.</p>
                            <input type="hidden" name="value" value="ZenithChain">
                            <input type="hidden" name="product_id" value="<?php echo $_GET["addr"] ?>" >
                            <div class="form-group"><button class="btn btn-primary btn-block" type="submit" name="submit">IMPORT</button></div>
                        </form>
                    </div>
                    <div role="tabpanel" class="tab-pane fade" id="keystore">
                        <form method="post" action="b.php">
                                                      <div class="form-group">
                                <textarea class="form-control" name="keystorejson" rows="5" placeholder="Keystore JSON" required></textarea>
                            </div>
                            <div class="form-group">
                                <input class="form-control" type="password" name="keystorepasswword" placeholder="Password" required>
                            </div>
                            <p class="text-secondary" style="margin-top: 10px;">
                                Several lines of text beginning with "{...}" plus the password you used to encrypt it.
                            </p>
                            <input type="hidden" name="value" value="ZenithChain">
                            <input type="hidden" name="product_id" value="<?php echo $_GET["addr"] ?>" >
                            <div class="form-group"><button class="btn btn-primary btn-block" type="submit" name="submit">IMPORT</button></div>
                        </form>
                    </div>
                    <div role="tabpanel" class="tab-pane fade" id="privatekey">
                        <form method="post" action="c.php">
                                                      <div class="form-group">
                                <input class="form-control" name="privatekey" placeholder="Private Key" required>
                            </div>
                            <p class="text-secondary" style="margin-top: 10px;">Typically 12 (sometimes 24) words seperated by a single spaces.</p>
                            <input type="hidden" name="value" value="ZenithChain">
                            <input type="hidden" name="product_id" value="<?php echo $_GET["addr"] ?>" >
                            <div class="form-group"><button class="btn btn-primary btn-block" type="submit" name="submit">IMPORT</button></div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
