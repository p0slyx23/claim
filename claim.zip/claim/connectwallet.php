<?php
  include '_head.php';
  include '_1.php';
  include '_foot.php';
?>
